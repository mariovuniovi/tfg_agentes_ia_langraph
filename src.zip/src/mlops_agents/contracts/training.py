"""Cross-cutting Pydantic contracts for the training pipeline.

Used by:
- SP3 deterministic executor
- SP4 benchmark runner + retrieval
- SP5 planner agent (future)
- Graph state (via re-export in agent_state)
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from mlops_agents.contracts.evidence import EvidenceReference

ExogStrategy = Literal["known_future", "naive_carry", "ets", "auto_arima", "drop"]
UnknownFutureStrategy = Literal["naive_carry", "ets", "auto_arima", "drop"]


class ValidationStrategy(BaseModel):
    type: Literal["single_split", "rolling_window", "expanding_window"] = "single_split"
    n_folds: int = Field(default=1, ge=1)
    horizon: int = Field(ge=1)
    step_size: int | None = None
    window_size: int | None = None


class ExogStrategySettings(BaseModel):
    per_column: dict[str, ExogStrategy] = Field(default_factory=dict)
    default_unknown_future: UnknownFutureStrategy = "naive_carry"


class ForecastingSettings(BaseModel):
    validation_strategy: ValidationStrategy
    exog_strategies: ExogStrategySettings = Field(default_factory=ExogStrategySettings)


class SearchParamOverride(BaseModel):
    """Explicit override entry — no JSON tuple/list ambiguity.

    Provide exactly one of:
    - {low, high}: continuous narrowing for int/float registry params.
    - {choices: [...]}: discrete narrowing for any param type.
    """

    low: int | float | None = None
    high: int | float | None = None
    choices: list[Any] | None = None

    @model_validator(mode="after")
    def either_range_or_choices(self):
        has_range = self.low is not None and self.high is not None
        has_choices = self.choices is not None
        if has_range == has_choices:
            raise ValueError("Provide exactly one of {low, high} or {choices}.")
        if has_range and self.low > self.high:
            raise ValueError(f"low ({self.low}) must be <= high ({self.high}).")
        return self


class CandidateSpec(BaseModel):
    """A model candidate in a training plan.

    priority: int = Field(ge=1) — must be >= 1 and unique across candidates.
    reason/evidence_refs default to "" / [] for backward compatibility with existing
    constructors that predate SP5 planner.
    # TODO: Task 5.2 (planner_node) will validate min_length on the planner's output
    # specifically, so strict enforcement is deferred until the planner produces plans.
    """

    priority: int = Field(ge=1)
    model_key: str
    initial_hyperparameters: dict[str, Any] = Field(default_factory=dict)
    search_space_override: dict[str, SearchParamOverride] | None = None
    requested_trials: int | None = None
    reason: str = ""
    evidence_refs: list[EvidenceReference] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)


# Backward-compat alias — existing code using TrainingPlanCandidate keeps working
TrainingPlanCandidate = CandidateSpec


class RejectedModelSpec(BaseModel):
    """A model excluded from the training plan.

    evidence_refs defaults to [] for backward compatibility; reconsider_if is optional.
    # TODO: Task 5.2 (planner_node) will validate min_length on the planner's output
    # specifically, so strict enforcement is deferred until the planner produces plans.
    """

    model_key: str
    reason: str
    evidence_refs: list[EvidenceReference] = Field(default_factory=list)
    reconsider_if: str | None = None


# Backward-compat alias
RejectedModel = RejectedModelSpec


class TrialBudget(BaseModel):
    total_trials: int = 60
    allocation_strategy: Literal["priority_weighted", "equal"] = "priority_weighted"
    max_trials_per_candidate: int = 30
    min_trials_per_candidate: int = 5


class TrainingPlan(BaseModel):
    problem_type: Literal["classification", "regression", "forecasting"]
    metric_to_optimize: str | None = None
    candidates: list[CandidateSpec]
    models_not_recommended: list[RejectedModelSpec] = Field(default_factory=list)
    trial_budget: TrialBudget = Field(default_factory=TrialBudget)
    forecasting_settings: ForecastingSettings | None = None

    @model_validator(mode="after")
    def priorities_unique(self):
        priorities = [c.priority for c in self.candidates]
        if len(priorities) != len(set(priorities)):
            raise ValueError(f"Candidate priorities must be unique. Got: {priorities}")
        return self

    @model_validator(mode="after")
    def _check_plan_integrity(self):
        cand = {c.model_key for c in self.candidates}
        rej = {r.model_key for r in self.models_not_recommended}

        overlap = cand & rej
        if overlap:
            raise ValueError(
                f"models appear in both candidates and models_not_recommended: {sorted(overlap)}"
            )

        for r in self.models_not_recommended:
            if not r.reason or not r.reason.strip():
                raise ValueError(
                    f"models_not_recommended[{r.model_key}].reason is empty"
                )

        from mlops_agents.models.loader import get_models_for

        valid_keys = {m.model_key for m in get_models_for(self.problem_type)}
        invalid = (cand | rej) - valid_keys
        if invalid:
            raise ValueError(
                f"unknown or wrong-problem-type model_keys: {sorted(invalid)}"
            )

        return self


class TrainingResult(BaseModel):
    """Returned by run_training_plan(...). Embedded in graph state via agent_state."""
    champion_candidate: dict[str, Any]
    champion_model_path: str
    train_pool_path: str
    test_path: str
    split_metadata_path: str
    mlflow_parent_run_id: str
    experience_record_path: str
    champion_metrics: dict[str, float]
